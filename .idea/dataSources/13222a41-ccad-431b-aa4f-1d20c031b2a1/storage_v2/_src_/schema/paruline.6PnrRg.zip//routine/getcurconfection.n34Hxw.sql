create procedure getCurConfection()
  BEGIN
    SELECT C.id_typeCC, nom_typeC, prix_typeC, ampleurC FROM typeconfectionC C, images_confectionC I
      WHERE C.id_typeCC = I.id_typeCC;
  END;

