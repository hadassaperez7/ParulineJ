create procedure getCustomers()
  BEGIN
    SELECT lastname, firstname, email, address, cp, city, phone
      FROM user U, customer CUS, city CIT
      WHERE U.id_user = CUS.id_user AND U.id_city = CIT.id_city AND U.id_user > 1 AND type = 'customer';
  END;

