create procedure getSheeDetails(IN idTypeVoilage int)
  BEGIN
    SELECT id_typeVoilages, ourlet FROM typeVoilage
      WHERE id_typeVoilages = idTypeVoilage;
  END;

