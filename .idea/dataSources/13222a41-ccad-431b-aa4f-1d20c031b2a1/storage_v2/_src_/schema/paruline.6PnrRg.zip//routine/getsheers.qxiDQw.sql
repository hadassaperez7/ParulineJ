create procedure getSheers(IN idshee int)
  BEGIN
    SELECT I.id_typeVoilages, nom_v, refV, hauteur, ourlet, prix_metre, colorisV, compositionV, src_imgV FROM typeVoilage V, image_voilages I
      WHERE id_voilages = idshee
      AND V.id_typeVoilages = I.id_typeVoilages;
  END;

