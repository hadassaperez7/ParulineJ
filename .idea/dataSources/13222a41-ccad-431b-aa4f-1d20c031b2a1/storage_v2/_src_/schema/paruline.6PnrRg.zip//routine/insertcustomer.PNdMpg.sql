create procedure InsertCustomer(IN firstnameCU varchar(50), IN lastnameCU varchar(10))
  BEGIN
    DECLARE iduser INT;
    SELECT MAX(id_user) INTO iduser FROM user;

    INSERT INTO customer(firstname, lastname, id_user) VALUES (firstnameCU, lastnameCU, iduser);
  END;

