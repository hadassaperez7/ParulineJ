create procedure userInfosCust(IN iduser int)
  BEGIN
    SELECT U.id_user, email, address, cp, city, phone, lastname, firstname FROM user U, customer CUS, city CIT
      WHERE U.id_user = CUS.id_user
            AND U.id_city = CIT.id_city
            AND U.id_user = iduser;
  END;

