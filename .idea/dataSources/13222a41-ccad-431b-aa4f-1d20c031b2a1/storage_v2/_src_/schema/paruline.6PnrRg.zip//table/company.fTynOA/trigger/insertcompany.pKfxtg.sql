create trigger InsertCompany
  before INSERT
  on company
  for each row
  BEGIN
  DECLARE nbu, nbcus INT;

  SELECT count(*) INTO nbu FROM user WHERE id_user = NEW.id_user;

  IF nbu = 0 THEN
    SIGNAL SQLSTATE '42000' SET MESSAGE_TEXT = 'Votre compte utilisateur n''existe pas.<br>';
  END IF;

  SELECT count(*) INTO nbcus FROM customer WHERE id_user = NEW.id_user;

  IF nbcus > 0 THEN
    SIGNAL SQLSTATE '42000' SET MESSAGE_TEXT = 'Vous êtes déjà un client particulier<br>';
  END IF;
END;

