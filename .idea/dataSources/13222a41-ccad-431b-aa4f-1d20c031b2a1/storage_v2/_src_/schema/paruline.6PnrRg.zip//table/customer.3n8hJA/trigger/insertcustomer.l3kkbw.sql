create trigger InsertCustomer
  before INSERT
  on customer
  for each row
  BEGIN
  DECLARE nbu, nbcomp INT;

  SELECT count(*) INTO nbu FROM user WHERE id_user = NEW.id_user;

  IF nbu = 0 THEN
    SIGNAL SQLSTATE '42000' SET MESSAGE_TEXT = 'Votre compte utilisateur n''existe pas <br>';
  END IF;

  SELECT count(*) INTO nbcomp FROM company WHERE id_user = NEW.id_user;

  IF nbcomp > 0 THEN
    SIGNAL SQLSTATE '42000' SET MESSAGE_TEXT = 'Vous êtes déjà un client professionnel <br>';
  END IF;
END;

