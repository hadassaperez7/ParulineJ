create trigger SUPPLigneCom
  after DELETE
  on `order`
  for each row
  BEGIN
  DECLARE qItem, qStock INT;

  SELECT stock INTO qStock FROM accessories WHERE id_order = OLD.id_order;
  SELECT nitems INTO qItem FROM order_items WHERE id_order = OLD.id_order;

  UPDATE accessories SET stock = qStock + qItem WHERE id_order = OLD.id_order;
END;

