create procedure checkExistsCity(IN cit varchar(100), IN cpCit varchar(5))
  BEGIN
    SELECT count(*) FROM city
      WHERE city = cit
            AND cp = cpCit;
  END;

