create procedure getCatCurtains()
  BEGIN
    SELECT id_rideaux, catTissu FROM rideaux;
  END;

