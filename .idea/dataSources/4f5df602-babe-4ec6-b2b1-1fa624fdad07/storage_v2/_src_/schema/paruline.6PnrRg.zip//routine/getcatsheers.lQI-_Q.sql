create procedure getCatSheers()
  BEGIN
    SELECT id_voilages, catVoilage FROM voilage;
  END;

