create procedure getProductData(IN idproducts int)
  BEGIN
    SELECT name_product, prTotalAccess FROM products P, accessories A, priceaccesso Pr
      WHERE P.id_products = A.id_products
            AND Pr.id_products = P.id_products
            AND P.id_products = idproducts LIMIT 1;
  END;

