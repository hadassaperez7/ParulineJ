create procedure getSheeConfection()
  BEGIN
    SELECT S.id_typeCS, S.nom_typeCS, prix_typeCS, ampleurCS FROM typeconfectionS S, images_confectionS I
      WHERE S.id_typeCS = I.id_typeCS;
  END;

