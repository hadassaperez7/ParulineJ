create procedure InsertPriceAcc(IN id int, IN prF float(10, 2), IN coefficient float(10, 2))
  BEGIN
    -- DECLARE lastID INT;
    DECLARE prPond, coeff, marge, total FLOAT(10,2) DEFAULT 0;

    SET prPond = prF * (1.30 / 100) + prF;
    SET coeff = prPond * (coefficient / 100);
    SET total = prPond + coeff;
    SET marge = total - prPond;

    -- SELECT MAX(id_products) FROM products;

    INSERT INTO priceaccesso(id_products, prFournisseur, prPondere, coeff, margeMonetaire, prTotalAccess)
    VALUES (id, prF, prPond, coefficient, marge, total);
  END;

