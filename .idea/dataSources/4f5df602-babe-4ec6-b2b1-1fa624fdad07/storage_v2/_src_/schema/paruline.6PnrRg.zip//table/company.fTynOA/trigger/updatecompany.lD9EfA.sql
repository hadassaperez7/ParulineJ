create trigger UpdateCompany
  after UPDATE
  on company
  for each row
  BEGIN
  UPDATE user SET id_user = NEW.id_user WHERE id_user = OLD.id_user;
END;

