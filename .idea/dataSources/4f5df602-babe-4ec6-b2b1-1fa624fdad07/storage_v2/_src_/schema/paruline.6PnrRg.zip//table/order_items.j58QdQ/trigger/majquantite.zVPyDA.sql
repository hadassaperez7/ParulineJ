create trigger MAJQuantite
  after INSERT
  on order_items
  for each row
  BEGIN
  DECLARE qItem, qStock, existStock INT;

  SELECT count(stock)INTO existStock FROM accessories, `order` WHERE id_order = NEW.id_order;
  SELECT stock INTO qStock FROM accessories, `order` WHERE id_order = NEW.id_order;
  SELECT nitems INTO qItem FROM order_items WHERE id_order = NEW.id_order;

  IF (existStock >= 0) THEN
    UPDATE accessories SET stock = 15 WHERE id_order = NEW.id_order;
  ELSE
    SIGNAL SQLSTATE '42000' SET MESSAGE_TEXT = 'La quantité est inférieure à 0.';
  END IF ;
END;

