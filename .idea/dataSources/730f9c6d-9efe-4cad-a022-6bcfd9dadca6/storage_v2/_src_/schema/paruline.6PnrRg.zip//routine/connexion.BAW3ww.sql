create procedure connexion(IN mail varchar(255), IN pwd varchar(255))
  BEGIN
    SELECT id_user, email, password, type FROM user WHERE email = mail AND password = pwd;
  END;

