create procedure getCity(IN cit varchar(100), IN cpCit varchar(5))
  BEGIN
    SELECT id_city FROM city WHERE city = cit AND cp = cpCit;
  END;

