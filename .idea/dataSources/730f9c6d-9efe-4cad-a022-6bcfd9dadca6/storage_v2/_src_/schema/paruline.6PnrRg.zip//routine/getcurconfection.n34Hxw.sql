create procedure getCurConfection()
  BEGIN
    SELECT id_typeCC, nom_typeC, prix_typeC FROM typeconfectionC;
  END;

