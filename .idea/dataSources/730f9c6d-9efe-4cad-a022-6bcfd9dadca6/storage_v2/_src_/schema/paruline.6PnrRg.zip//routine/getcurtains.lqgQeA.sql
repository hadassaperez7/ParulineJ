create procedure getCurtains(IN idrid int)
  BEGIN
    SELECT T.id_typeRideaux, nom_t, refT, largeur, prix_au_Metre, raccord, rapport, coloris, compositionT, src_imgT FROM tissus T, images_tissus I
      WHERE id_rideaux = idrid
      AND T.id_typeRideaux = I.id_typeRideaux;
  END;

