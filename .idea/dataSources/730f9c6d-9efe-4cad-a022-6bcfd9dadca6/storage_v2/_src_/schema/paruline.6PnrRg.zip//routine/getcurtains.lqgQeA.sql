create procedure getCurtains(IN idrid int)
  BEGIN
    SELECT id_typeRideaux, nom_t, prix_au_Metre FROM tissus WHERE id_rideaux = idrid;
  END;

