create procedure getCustomersPro()
  BEGIN
    SELECT lastname_contact, firstname_contact, company, type_comp, email, address, cp, city, phone
    FROM user U, company COMP, city CIT
    WHERE U.id_user = COMP.id_user AND U.id_city = CIT.id_city AND U.id_user > 1 AND type = 'company';
  END;

