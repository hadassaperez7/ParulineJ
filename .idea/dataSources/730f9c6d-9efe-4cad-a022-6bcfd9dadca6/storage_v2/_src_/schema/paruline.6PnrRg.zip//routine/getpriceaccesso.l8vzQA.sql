create procedure getPriceAccesso()
  BEGIN
    SELECT P.id_products, name_product, ref, name_f, prFournisseur, prPondere, coeff, margeMonetaire, prTotalAccess
    FROM products P, fournisseur F, priceaccesso Pr
    WHERE P.id_products = Pr.id_products AND P.id_fourniss = F.id_fourniss;
  END;

