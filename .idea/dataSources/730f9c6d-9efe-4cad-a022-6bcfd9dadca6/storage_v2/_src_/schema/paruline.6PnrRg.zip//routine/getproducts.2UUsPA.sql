create procedure getProducts()
  BEGIN
    SELECT P.id_products, A.id_products, name_product, prTotalAccess, description FROM products P, accessories A, priceaccesso Pr
    WHERE P.id_products = A.id_products AND Pr.id_products = P.id_products ORDER BY name_product ASC;
  END;

