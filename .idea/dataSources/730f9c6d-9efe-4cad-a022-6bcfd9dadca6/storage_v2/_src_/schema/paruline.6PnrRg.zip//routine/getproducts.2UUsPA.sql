create procedure getProducts()
  BEGIN
    SELECT P.id_products, A.id_products, name_product, prTotalAccess, description, src_imgPr FROM products P, accessories A, priceaccesso Pr, images_product I
      WHERE P.id_products = A.id_products
          AND Pr.id_products = P.id_products
          AND P.id_products = I.id_products
    ORDER BY name_product ASC;
  END;

