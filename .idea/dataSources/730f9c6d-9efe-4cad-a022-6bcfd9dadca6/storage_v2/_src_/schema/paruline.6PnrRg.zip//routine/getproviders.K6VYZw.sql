create procedure getProviders()
  BEGIN
    SELECT name_f, adresse_f FROM fournisseur;
  END;

