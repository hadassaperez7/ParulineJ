create procedure getSheeConfection()
  BEGIN
    SELECT id_typeCS, nom_typeCS, prix_typeCS FROM typeconfectionS;
  END;

