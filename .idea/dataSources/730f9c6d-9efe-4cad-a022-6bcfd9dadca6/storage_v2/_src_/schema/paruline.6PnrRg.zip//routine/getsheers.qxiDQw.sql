create procedure getSheers(IN idshee int)
  BEGIN
    SELECT nom_v, ourlet, prix_metre FROM typeVoilage WHERE id_voilages = idshee;
  END;

