create procedure InsertCity(IN newCity varchar(100), IN newCP varchar(5))
  BEGIN
    INSERT INTO city(city, cp) VALUES (newCity, newCP);
  END;

