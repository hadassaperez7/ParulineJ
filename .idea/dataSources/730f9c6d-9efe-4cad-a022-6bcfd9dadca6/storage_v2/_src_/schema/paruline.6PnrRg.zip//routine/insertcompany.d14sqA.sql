create procedure InsertCompany(IN companyCO           varchar(50), IN type_compCO varchar(10),
                               IN lastname_contactCO  varchar(50), IN firstname_contactCO varchar(50))
  BEGIN
    DECLARE iduser INT;
    SELECT MAX(id_user) INTO iduser FROM user;

    INSERT INTO company(company, type_comp, lastname_contact, firstname_contact, id_user) VALUES (companyCO, type_compCO, lastname_contactCO, firstname_contactCO, iduser);
  END;

