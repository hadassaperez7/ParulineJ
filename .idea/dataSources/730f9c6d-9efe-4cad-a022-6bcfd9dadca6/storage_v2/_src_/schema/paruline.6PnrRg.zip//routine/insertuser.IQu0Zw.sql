create procedure InsertUser(IN idcity    varchar(100), IN gend varchar(4), IN emailU varchar(255),
                            IN passwordU varchar(255), IN addressU varchar(100), IN phoneU varchar(20),
                            IN typeU     varchar(8))
  BEGIN

    INSERT INTO user(id_city, gender, email, password, address, phone, type) VALUES (idcity, gend, emailU, passwordU, addressU, phoneU, typeU);

  END;

