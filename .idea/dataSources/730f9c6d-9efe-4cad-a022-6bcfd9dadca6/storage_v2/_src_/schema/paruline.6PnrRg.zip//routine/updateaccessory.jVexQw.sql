create procedure updateAccessory(IN name_p varchar(150), IN descriptionP text, IN idproducts int)
  BEGIN
    UPDATE products P SET P.name_product = name_p WHERE P.id_products = idproducts;

    UPDATE accessories A SET A.description = descriptionP  WHERE A.id_products = (SELECT P.id_products FROM products P WHERE P.id_products = idproducts);
  END;

