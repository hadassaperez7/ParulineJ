create procedure updateCompany(IN companyCO varchar(50), IN typeCO varchar(10), IN iduser int)
  BEGIN
    UPDATE user U, company COM
    SET company = companyCO, type_comp = typeCO
    WHERE U.id_user = COM.id_user AND U.id_user = iduser;
  END;

