create procedure updateConnexion(IN emailC varchar(255), IN passwordC varchar(255), IN iduser int)
  BEGIN
    UPDATE user SET email = emailC, password = passwordC WHERE id_user = iduser;
  END;

