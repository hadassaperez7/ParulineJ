create procedure updateGeneralCOMP(IN lastname varchar(50), IN firstname varchar(50), IN addressCO varchar(100),
                                   IN phoneCO  varchar(20), IN cityCO varchar(100), IN cpCO varchar(5), IN iduser int)
  BEGIN
    DECLARE exist, idcity INT;

    SELECT count(*) INTO exist FROM city WHERE city = cityCO AND cp = cpCO;

    IF (exist = 0) THEN
      INSERT INTO city(city, cp) VALUES (cityCO, cpCO);
      SELECT MAX(id_city) INTO idcity FROM city;

      UPDATE user SET address = addressCO, phone = phoneCO, id_city = idcity WHERE id_user = iduser;
    ELSE
      SELECT DISTINCT(CIT.id_city) INTO idcity FROM city CIT WHERE CIT.city = cityCO AND CIT.cp = cpCO;

      UPDATE user U SET U.address = addressCO, U.phone = phoneCO, U.id_city = idcity WHERE U.id_user = iduser;

    END IF;

    UPDATE company
    SET lastname_contact = lastname, firstname_contact = firstname
    WHERE id_user = iduser;

  END;

