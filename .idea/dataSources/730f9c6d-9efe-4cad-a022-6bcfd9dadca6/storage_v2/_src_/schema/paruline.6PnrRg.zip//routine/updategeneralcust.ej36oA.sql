create procedure updateGeneralCUST(IN lastnameCUST varchar(50), IN firstnameCUST varchar(50),
                                   IN addressCUST  varchar(100), IN phoneCUST varchar(20), IN cityCUST varchar(100),
                                   IN cpCUST       varchar(5), IN iduser int)
  BEGIN
    DECLARE exist, idcity INT;

    SELECT count(*) INTO exist FROM city WHERE city = cityCUST AND cp = cpCUST;

    IF (exist = 0) THEN
      INSERT INTO city(city, cp) VALUES (cityCUST, cpCUST);
      SELECT MAX(id_city) INTO idcity FROM city;

      UPDATE user
        SET address = addressCUST, phone = phoneCUST, id_city = idcity
        WHERE id_user = iduser;
    ELSE
      SELECT DISTINCT(CIT.id_city) INTO idcity FROM city CIT WHERE CIT.city = cityCUST AND CIT.cp = cpCUST;

      UPDATE user U
        SET U.address = addressCUST, U.phone = phoneCUST, U.id_city = idcity
        WHERE U.id_user = iduser;

    END IF;

    UPDATE customer
      SET lastname = lastnameCUST, firstname = firstnameCUST
      WHERE id_user = iduser;

  END;

