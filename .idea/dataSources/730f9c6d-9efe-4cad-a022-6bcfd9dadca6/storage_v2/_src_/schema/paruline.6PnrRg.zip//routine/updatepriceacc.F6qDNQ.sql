create procedure UpdatePriceAcc(IN id int, IN refP varchar(100), IN prF float(10, 2), IN coefficient float(10, 2))
  BEGIN
    DECLARE prPond, coeff, marge, total FLOAT(10,2) DEFAULT 0;

    SET prPond = prF * (1.30 / 100) + prF;
    SET coeff = prPond * (coefficient / 100);
    SET total = prPond + coeff;
    SET marge = total - prPond;

    UPDATE priceaccesso SET prFournisseur = prF, prPondere = prPond, coeff = coefficient, margeMonetaire = marge, prTotalAccess = total
      WHERE id_products = id;

    UPDATE products SET ref = refP
      WHERE id_products = id;
  END;

