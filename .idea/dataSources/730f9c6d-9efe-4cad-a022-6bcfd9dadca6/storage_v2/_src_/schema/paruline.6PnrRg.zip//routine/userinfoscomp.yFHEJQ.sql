create procedure userInfosComp(IN iduser int)
  BEGIN
    SELECT u.id_user, email, password, address, cp, city, phone, company, type_comp, lastname_contact, firstname_contact
      FROM user U, company COM, city CIT
      WHERE COM.id_user = U.id_user AND U.id_city = CIT.id_city AND U.id_user = iduser;
  END;

