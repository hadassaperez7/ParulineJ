create trigger DeleteCompany
  after DELETE
  on user
  for each row
  BEGIN
  DELETE FROM company WHERE id_user = OLD.id_user;
END;

